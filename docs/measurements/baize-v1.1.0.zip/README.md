# 白泽车载升级 v1.1.0

本包供 STM32F103RC 白泽底盘与 RDK X5 使用。解压后在本目录校验文件。

```sh
sha256sum -c SHA256SUMS
baize-update info
sudo baize-update install ./baize-1.1.0.bin
```

随包的 `baize-monitor-linux-arm64` 是 X5 原生构建的监视工具，可用 `sudo install -m755 baize-monitor-linux-arm64 /usr/local/bin/baize-monitor` 安装。

首次部署工具时，在 X5 的 Python 3.10 虚拟环境运行 `pip install -c x5-requirements.txt ./baize_update-1.1.0-py3-none-any.whl`。车上的工具已安装，正式包另存在 `/opt/baize-update/images/baize-1.1.0.bin`。日常使用紧凑的串口包。首次从无引导的旧布局迁移时，先在 ST-LINK 上备份原 Flash，再从 0x08000000 安装 `baize-factory.bin`。

`manifest.json` 记录构建来源、板型和镜像摘要。原车备份由车主保存在开发电脑和 X5 上。维护串口接受开发者自己的同型号构建。

`records/` 保存首装读回结果、systemd 日志、失败与回退、满槽、旧程序实车回归和板端时间序列。带 `passive` 的记录在候选未确认时仅读底盘上报。带 `delivered` 的记录取自最终装回的正式版。轮速和 IMU 频率按去重后的板端时间复算，分析连接初段 USB 缓冲时应保留原始时间次序。真实整车断电未实测。

[升级、恢复与实车验收](https://github.com/1229282331/baize/blob/v1.1.0/docs/firmware-update.md) · [发布源码](https://github.com/1229282331/baize/tree/v1.1.0)
