# 白泽移动底盘 v1.0.0

本包用于这辆空载、未装机械臂的四轮底盘。固件和主机库的实现提交为 `80fe65c08b5260e75c096f2e95645db29a84de94`。四轮依次为左前、右前、左后、右后，前进方向为正。板载 CH340 使用 115200 bit/s、8N1。

## 连接底盘

Windows 双击 `host/panel/启动底盘控制台.cmd`，选板载 CH340 并连接。本机实测为 COM17。面板需 Python 3.10 及以上及 Tk，串口库已随包提供。Linux 可运行 `python3 -B host/panel/baize-panel.pyw --port /dev/ttyUSB0`，端口随机器调整。

用 `bin/windows-x86_64/baize-monitor.exe COM17 100 --imu-csv imu.csv` 采集两路反馈。将 C++ 示例复制到项目外，用 `cmake -S <示例目录> -B build/example -DBAIZE_SOURCE_DIR=<解压目录>` 及 `cmake --build build/example` 构建。运行 `chassis-example COM17` 会给四轮 +0.5 rad/s 持续 0.3 秒，然后停机、关闭并重新连接。Linux 可执行文件在 `bin/linux-x86_64/`。C、C++ 应用均可链接 CMake 目标 `baize_host`，平台静态库在 `lib/`。[会话、协议及 ROS 2 映射](docs/base-interface.md)

## 空载实测

本车在现场平整地面，直行四轮双向复核的速度幅值边界为 0.35～1.5 rad/s，单趟 1.6 秒。转向用独立的左右转试次核对。车轮编码器给出轮端位移与停稳反馈，里程估算采用厂商标称轮周长 0.496371 m 和轮距 0.265 m。地面真实行程、车身停距和负载工况未测。IMU 安装轴向按水平、抬头和转向实测记录，原始六轴保留静止偏置。

运动中拔掉 A–A 线后，最后有效目标到四路输出全部归中的观测上界为 151 ms。小时级静止实线采集在 Windows 有三次接收间隔超过 250 ms，最大 765 ms。主机按轮反馈新鲜度执行停机握手。

## 固件、回退与核验
本包的 `firmware/`、`protocol/` 含完整固件源码和对应版本的 HAL、CMSIS、链接脚本及工具锁。在 `firmware/` 中依次执行 `cube bundle install --project`、`cube cmake --preset Release`、`cube cmake --build --preset Release`。用配套 Arm 工具的 `arm-none-eabi-objcopy -O binary build/Release/baize_base.elf rebuilt.bin` 导出应用，比较 `rebuilt.bin` 和同目录 `chassis.bin` 的 SHA-256。

四轮架空并用底盘原电源供电。写入本车应用及其原页尾，随后独立读回相同的 22528 字节。

```powershell
cube programmer -c port=SWD freq=480 reset=SWrst -d firmware/chassis-pages.bin 0x08000000 -v -rst
cube programmer -c port=SWD freq=480 mode=HOTPLUG -u 0x08000000 22528 readback.bin
Get-FileHash firmware/chassis-pages.bin,readback.bin -Algorithm SHA256
```

回退时用 `firmware/rollback-pages.bin` 替换写入及哈希比对文件。回退镜像是本车上一份带独立看门狗的 5 ms PI 候选。两份镜像的完整实车读回、切换记录和旧工具兼容试验位于 `records/`。

## 原始记录与复算

逐文件 SHA-256 见 `SHA256SUMS`。从解压目录执行以下命令可复算现场结果、台架试次和一小时记录。

```text
python -B analysis/visit_report.py records/empty-field records/empty-field/ground
python -B docs/measurements/wheel_acceptance.py replay records/raised-panel
python -B analysis/continuous_usb.py records/continuous-usb
```

源码、完整验收文档和历史记录见[版本仓库](https://github.com/1229282331/baize/tree/v1.0.0)。
