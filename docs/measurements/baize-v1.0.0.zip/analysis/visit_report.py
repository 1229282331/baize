"""Recompute physical disconnect timing, signed IMU axes and ground trial summaries."""
import csv
import binascii
import json
import math
import statistics
import struct
import sys
from pathlib import Path

for parent in Path(__file__).resolve().parents:
    measurements=parent/"docs/measurements"
    if (measurements/"wheel_acceptance.py").is_file():
        sys.path.insert(0,str(measurements))
        break
from wheel_acceptance import replay
from wheel_floor import measure
from wheel_response import WHEELS, crossing_ms

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

def rows(path):
    with path.open(encoding="utf-8",newline="") as fp:return list(csv.DictReader(fp))

def dot(u,v): return sum(a*b for a,b in zip(u,v))
def unit(v): return [x/math.hypot(*v) for x in v]
def cross(u,v):
    return [u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0]]

def decode(text):
    data=bytes.fromhex(text)
    if not data or data[-1]!=0:return None
    raw=bytearray()
    i=0
    while i<len(data)-1:
        end=i+data[i]
        if not i<end<=len(data)-1:return None
        raw.extend(data[i+1:end])
        if end<len(data)-1:raw.append(0)
        i=end
    if len(raw)<4 or raw[0]!=1 or binascii.crc_hqx(raw[:-2],0xffff)!=int.from_bytes(raw[-2:],"little"):return None
    layout={1:"",2:"",3:"4i",129:"IBBH4q4i",130:"I6i"}.get(raw[1])
    if layout is None or len(raw)-4!=struct.calcsize("<"+layout):return None
    return (raw[1],*struct.unpack("<"+layout,raw[2:-2]))

def disconnect(visit):
    result=read(visit/"unplug.json")
    history=rows(visit/result["record_directory"]/"swd.csv")
    stop=next(r for r in history if int(r["state_reason"])==0x300 and all(int(r["ccr"+str(i)])==2000 for i in range(1,5)))
    assert any(int(r["state_reason"])==1 and any(int(r["ccr"+str(i)])!=2000 for i in range(1,5)) for r in history)
    bound=(int(stop["board_after_ms"])-result["last_target_ms"])%2**32
    assert bound==result["neutral_delay_upper_ms"] and 150<=bound<=155
    assert all(result[k] for k in ("host_port_absent","reenumerated","stale_target_ignored","enable_alone_zero","new_target_seen"))
    messages=[(r["dir"],decode(r["wire_hex"])) for r in rows(visit/result["record_directory"]/"reconnect-wire.csv")]
    valid=[(direction,p) for direction,p in messages if p]
    tx=[(j,p) for j,(direction,p) in enumerate(valid) if direction=="tx"]
    assert tx[0][1]==(3,400,400,400,400) and tx[1][1]==(1,) and tx[2][1]==(2,)
    def feedback(start,end):
        return [p for direction,p in valid[start+1:end] if direction=="rx" and p[0]==129]
    assert any(p[2:4]==(0,3) and p[9:13]==(0,)*4 for p in feedback(tx[0][0],tx[1][0]))
    assert any(p[2:4]==(1,0) and p[9:13]==(0,)*4 for p in feedback(tx[2][0],tx[3][0]))
    assert tx[3][1]==(3,450,450,450,450) and tx[-1][1]==(1,)
    assert any(min(p[9:13])>220 for p in feedback(tx[3][0],tx[-1][0]))
    assert any(p[2:4]==(0,2) for p in feedback(tx[-1][0],len(valid)))
    return result

def axes(visit):
    data=read(visit/"tilt.json")
    pose_frames={name:[] for name in data}
    for row in rows(visit/"tilt-wire.csv"):
        p=decode(row["wire_hex"])
        if p and p[0]==129:assert p[2]==0
        if p and p[0]==130 and row["phase"] in pose_frames:pose_frames[row["phase"]].append(p)
    for phase,frames in pose_frames.items():
        samples=frames[-65:]
        assert len(samples)==65 and all(0<(b[1]-a[1])%2**32<=45 for a,b in zip(samples,samples[1:]))
        values=[statistics.mean(p[i]/1000 for p in samples) for i in range(2,8)]
        assert all(abs(u-v)<1e-8 for u,v in zip(values,data[phase]))
    flat,up,again=[data[k] for k in ("level","nose-up","level-again")]
    z=unit(flat[:3])
    gz=dot(up[:3],z)
    x=unit([a-gz*b for a,b in zip(up[:3],z)])
    basis=[x,cross(z,x),z]
    rotation=[]
    for axis in basis:
        i=max(range(3),key=lambda j:abs(axis[j]))
        if abs(axis[i])<.90:raise ValueError("physical poses do not support an axis-aligned mount")
        rotation.append([((1 if axis[i]>0 else -1) if j==i else 0) for j in range(3)])
    assert cross(rotation[0],rotation[1])==rotation[2]
    return dict(sensor_to_body_signed_axes=rotation,level_acceleration_m_s2=flat[:3],nose_up_acceleration_m_s2=up[:3],
                flat_return_acceleration_m_s2=again[:3],level_gravity_m_s2=math.hypot(*flat[:3]),
                direction_change_deg=math.degrees(math.acos(dot(unit(flat[:3]),unit(up[:3])))),
                static_gyro_rad_s=flat[3:],full_six_pose_calibration=False)

def verify_grade(folder,run):
    control=[{k:int(v) for k,v in row.items()} for row in rows(folder/run["label"]/"control.csv")]
    target=round(1000*run["targets"][0])
    valid=[r for r in control if r["state"]==1 and all(r["target_mrad_s_"+w]==target for w in WHEELS)]
    origin=valid[0]["last_command_ms"]
    valid=[r for r in valid if r["ms"]>=origin]
    if len(valid)<122:raise ValueError("short control recording")
    measured=list(measure(valid[-121:],valid[-121]["ms"],target,"rest"))
    start=[valid[0]]
    for r in valid[1:]:
        if r["ms"]-start[-1]["ms"]!=5:break
        start.append(r)
    times=[r["ms"]-origin for r in start]
    if times[0]>5:raise ValueError("missing initial control cycle")
    sign=1 if target>0 else -1
    for saved,m in zip(run["metrics"],measured):
        w=m["wheel"]
        for key in ("wheel","p95_error_pct","continuous_ok","smooth_ok","worst_100ms_error_pct","max_no_progress_ms"):
            assert m[key]==saved[key],(run["label"],w,key)
        t50=crossing_ms(times,[r["speed_mrad_s_"+w]*sign for r in start],abs(target)*.5)
        assert saved["t50_ms"]==t50
        assert saved["start_ok"]==(t50 is not None and t50<=250)
        effort=sorted(abs(r["pwm_"+w]) for r in valid[-120:])
        assert saved["p95_tail_pwm"]==effort[math.ceil(.95*len(effort))-1] and saved["peak_tail_pwm"]==effort[-1]
    return all(w["start_ok"] and w["smooth_ok"] and w["p95_tail_pwm"]<700 for w in run["metrics"])

def ground_result(folder,imu):
    session=folder/"serial"
    wheel_rows=rows(session/"wheels.csv")
    imu_rows=rows(session/"imu.csv")
    summary=replay(session)
    trials=read(folder/"runs.json")
    checked={t["id"]:t for t in summary["trials"]}
    settling=[]
    turns={}
    tested={}
    for record in trials:
        key=record["trial"]
        trial=checked[key]
        assert trial["settled"] and trial["stop_ack"] and trial["outcome"]=="completed"
        assert trial["mean_rad_s"]==record["mean_rad_s"]
        wr=[r for r in wheel_rows if r["trial"]==key]
        last_enabled=max(i for i,r in enumerate(wr) if r["drive_state"]=="1")
        ack=next(int(r["board_ms"]) for r in wr[last_enabled+1:] if r["drive_state"]=="0" and r["stop_reason"]=="2")
        quiet=(int(wr[-1]["board_ms"])-trial["quiet_ms"])%2**32
        settling.append((quiet-ack)%2**32)
        if record["label"].startswith("turn-"):
            start=record["first_drive_ms"]
            elapsed=(record["last_drive_ms"]-start)%2**32
            raw=[[float(r[k]) for k in ("gx_rad_s","gy_rad_s","gz_rad_s")] for r in imu_rows
                 if r["trial"]==key and 250<(int(r["board_ms"])-start)%2**32<elapsed-100]
            assert len(raw)>=30
            corrected=[dot(imu["sensor_to_body_signed_axes"][2],[v-b for v,b in zip(a,imu["static_gyro_rad_s"])]) for a in raw]
            turns[record["label"]]=dict(samples=len(raw),median_body_yaw_rad_s=statistics.median(corrected),
                                     wheel_targets=record["targets"],mean_wheel_rad_s=record["mean_rad_s"],tail_peak_pwm=record["tail_peak_pwm"])
        elif record.get("passed") is not None:
            assert (verify_grade(folder,record) and trial["assessment"]=="反馈符合")==record["passed"]
            tested[record["label"]]=record["passed"]
    voltage=[float(r["supply_v"]) for r in wheel_rows if r["supply_v"]]
    grades=read(folder/"range-grades.json")
    pairs={}
    for record in trials:
        if not record["label"].startswith("turn-"):
            phase,magnitude,attempt,direction=record["label"].split("-")
            pairs.setdefault((phase,str(int(magnitude)/1000)),{}).setdefault(int(attempt),{})[direction]=record["passed"]
    for (phase,magnitude),attempts in pairs.items():
        last=attempts[max(attempts)]
        assert set(last)=={"forward","reverse"}
        expected=None if None in last.values() else all(last.values())
        assert grades["initial" if phase=="range" else "repeat"][magnitude]==expected
    bounds=sorted(float(v) for v,value in grades["repeat"].items() if value is True and grades["initial"].get(v) is True)
    observation=read(folder/"observation.json") if (folder/"observation.json").exists() else None
    example=(folder/"example.log").read_text()
    assert "Stopped and reconnected with drive disabled." in example and "imu " in example and "wheels " in example
    return dict(conditions=read(folder/"conditions.json"),observation=observation,trial_count=len(trials),
                grades=grades,double_checked_bounds_rad_s=bounds,turns=turns,verified_straight_traces=len(tested),
                wheel_still_after_first_disabled_ack_ms=[min(settling),max(settling)],supply_v=[min(voltage),max(voltage)],
                wheel_stream=summary["wheels"],imu_stream=summary["imu"],standalone_cpp_stop_reconnect=True)

if __name__=="__main__":
    visit=Path(sys.argv[1])
    imu=axes(visit)
    report=dict(physical_unplug=disconnect(visit),imu=imu,ground=ground_result(Path(sys.argv[2]),imu))
    print(json.dumps(report,ensure_ascii=True,indent=2,allow_nan=False))
