"""Independently decode qualification wire logs and recompute the timed release checks."""
import binascii
import csv
import hashlib
import json
import os
import struct
import sys
from collections import Counter
from pathlib import Path

records=Path(sys.argv[1]) if len(sys.argv)>1 else Path(os.environ["LOCALAPPDATA"])/"Baize/Validation/20261122-v1-qualification"
def decode(wire):
    assert wire[-1]==0
    data=wire[:-1];raw=bytearray();i=0
    while i<len(data):
        j=i+data[i]
        if not i<j<=len(data):return None
        raw.extend(data[i+1:j])
        if j<len(data):raw.append(0)
        i=j
    if len(raw)<4 or raw[0]!=1 or int.from_bytes(raw[-2:],"little")!=binascii.crc_hqx(raw[:-2],0xffff):return None
    fmt={1:"",2:"",3:"4i",129:"IBBH4q4i",130:"I6i"}.get(raw[1])
    if fmt is None or struct.calcsize("<"+fmt)!=len(raw)-4:return None
    return (raw[1],*struct.unpack("<"+fmt,raw[2:-2]))

def messages(name):
    with (records/(name+".csv")).open(newline="") as f:
        for row in csv.DictReader(f):
            parsed=decode(bytes.fromhex(row["wire_hex"]))
            yield row,parsed

res={}
cases=json.loads((records/"usb-stops.json").read_text())
assert len(cases)==30
for mode in ("stop","silent","invalid"):
    times=[]
    for case in (c for c in cases if c["mode"]==mode):
        got=[(r["dir"],p) for r,p in messages(case["name"]+"-wire")]
        valid=[(d,p) for d,p in got if p]
        assert any(d=="tx" and p[0]==3 and p[1:]==(550,-650,750,-850) for d,p in valid)
        assert any(d=="rx" and p[0]==129 and p[2:4]==(1,0) for d,p in valid)
        assert any(d=="rx" and p[0]==129 and p[2:4]==(0,2 if mode=="stop" else 3) for d,p in valid)
        if mode=="invalid":
            assert any(d=="tx" and p is None for d,p in got)
            assert any(d=="tx" and p[0]==3 and p[-1]==2001 for d,p in valid)
        assert case["ccr"]==[2000]*4
        times.append((case["neutral_ms"]-case["origin_ms"])%(2**32))
    assert len(times)==10
    assert (0<=min(times) and max(times)<=5) if mode=="stop" else (150<=min(times) and max(times)<=155)
    res[mode]=dict(runs=len(times),min_ms=min(times),max_ms=max(times))

watch=json.loads((records/"usb-watchdog.json").read_text())
assert {(x["moving"],x["event"]) for x in watch}=={(v,k) for v in (False,True) for k in ("HardFault","main-stall")}
for x in watch:
    assert x["ccr"]==[2000]*4 and 0<x["lower_ms"]<x["upper_ms"]<150
    if x["event"]=="HardFault":assert 3 in x["ipsr"]
res["watchdog_reset_bounds_ms"]=[min(x["lower_ms"] for x in watch),max(x["upper_ms"] for x in watch)]

for mode in ("example","stale"):
    wire=list(messages("linux-real-usb-"+mode+"-wire"))
    commands=[(float(r["host_s"]),p[0]) for r,p in wire if r["direction"]=="tx"]
    assert {k for t,k in commands}=={1,2,3}
    assert commands[0][1]==1
    hold=next(t for t,k in commands if k==3)
    stop=next(t for t,k in commands if t>=hold and k==1)
    assert all(k!=3 for t,k in commands if t>=stop)
    if mode=="example":
        targets=[t for t,k in commands if k==3]
        assert len(targets)>=2 and all(len(bytes.fromhex(r["wire_hex"]))==22
            for r,p in wire if r["direction"]=="tx" and p[0]==3)
        byte_rate=22*(len(targets)-1)/(targets[-1]-targets[0])
        res["example_target_stream"]=dict(targets=len(targets),intervals_ms=round(1000*(targets[-1]-targets[0]),2),
            bytes_s=round(byte_rate,2),percent_115200_8n1=round(100*byte_rate/11520,3))
    if mode=="stale":
        before=[(float(r["host_s"]),p[0],int(r["delivered_to_application"])) for r,p in wire
                if r["direction"]=="rx" and p and float(r["host_s"])<=stop]
        last=max(t for t,k,forwarded in before if k==129 and forwarded)
        gap=(stop-last)*1000
        assert 220<gap<340 and sum(1 for t,k,f in before if t>last and k==130 and f)>=8
        res["linux_last_fresh_wheel_to_stop_ms"]=round(gap,2)

prod=json.loads((records/"production-usb.json").read_text())
lost=prod["abrupt_process_exit"]
res["host_exit_to_neutral_from_last_target_ms"]=lost["observed_control_tick"]-lost["last_target_ms"]
assert 150<=res["host_exit_to_neutral_from_last_target_ms"]<=155 and lost["stop_reason"]==3
gap=prod["imu_gap"]
with (records/"release-imu-gap-wheels.csv").open() as f:w=[int(r["board_ms"]) for r in csv.DictReader(f)]
with (records/"release-imu-gap-imu.csv").open() as f:a=[int(r["board_ms"]) for r in csv.DictReader(f)]
assert all(b-a0==20 for a0,b in zip(w,w[1:]))
assert not any(gap["masked_ms"]+30<t<gap["restored_ms"] for t in a)
assert sum(gap["masked_ms"]<t<gap["restored_ms"] for t in w)==gap["wheel_frames_while_masked"]
assert min(t for t in a if t>=gap["restored_ms"])-gap["restored_ms"]==gap["first_new_after_ms"]
print(json.dumps(res,indent=2))
