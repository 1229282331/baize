"""Recompute the one-hour stationary CH340 acceptance from the shipped raw CSVs."""
import argparse
import csv
import json
import math
from collections import Counter
from pathlib import Path


def stream(path, wheel):
    intervals = Counter()
    host_intervals = Counter()
    expired = []
    reasons = Counter()
    voltage_min, voltage_max = math.inf, -math.inf
    fields = [f"{w}_rad" for w in ("fl", "fr", "rl", "rr")]
    previous = None
    first_host = elapsed = count = 0
    with path.open(encoding="utf-8-sig", newline="") as data:
        for row in csv.DictReader(data):
            host, board = int(row["host_elapsed_ms"]), int(row["board_ms"])
            if previous is None:
                first_host = host
                if wheel:
                    origin = tuple(float(row[k]) for k in fields)
            else:
                delta = (board - previous[1]) % 2**32
                host_gap = host - previous[0]
                if not 0 < delta < 250 or host_gap < 0:
                    raise ValueError(f"{path.name}: discontinuous sample at board_ms={board}")
                if host_gap >= 250:
                    expired.append(dict(previous_host_ms=previous[0], host_ms=host, host_gap_ms=host_gap,
                                        previous_board_ms=previous[1], board_ms=board, board_gap_ms=delta))
                elapsed += delta
                intervals[delta] += 1
                host_intervals[host - previous[0]] += 1
            if wheel:
                angles = tuple(float(row[k]) for k in fields)
                if row["drive_state"] != "0" or angles != origin or any(float(row[k+"_s"]) for k in fields):
                    raise ValueError(f"{path.name}: motion or unexpected drive state at board_ms={board}")
                reasons[int(row["stop_reason"])] += 1
                volts = float(row["supply_v"])
                if not math.isfinite(volts) or volts <= 0:
                    raise ValueError(f"{path.name}: invalid supply reading at board_ms={board}")
                voltage_min, voltage_max = min(voltage_min, volts), max(voltage_max, volts)
            previous = host, board
            count += 1
    if not intervals or not previous:
        raise ValueError(f"{path.name}: no complete sample intervals")
    hz = (count - 1) * 1000 / elapsed
    result = dict(frames=count, board_span_ms=elapsed, host_span_ms=previous[0]-first_host,
                  hz=hz, board_gap_ms=dict(sorted(intervals.items())), max_host_gap_ms=max(host_intervals),
                  host_gaps_250ms_or_more=expired,
                  wire_bytes_per_second=hz * (62 if wheel else 34))
    if wheel:
        result.update(stop_reasons=dict(reasons), supply_v=[voltage_min, voltage_max])
    return result


def audit(directory):
    run = json.loads((directory/"soak-run.json").read_text(encoding="utf-8"))
    if run["returncode"] != 0 or run["seconds"] < 3600 or (directory/"soak-stderr.txt").stat().st_size:
        raise ValueError("the continuous monitor run must complete one hour without errors")
    wheels = stream(directory/"soak-wheels.csv", True)
    imu = stream(directory/"soak-imu.csv", False)
    if wheels["frames"] != 180500 or imu["frames"] <= 178000 or min(
            wheels["board_span_ms"], imu["board_span_ms"]) < 3600000:
        raise ValueError("the raw streams do not cover the requested one-hour capture")
    if set(wheels["stop_reasons"]) != {2}:
        raise ValueError("unexpected wheel stop reason during the stationary run")
    bps = wheels["wire_bytes_per_second"] + imu["wire_bytes_per_second"]
    return dict(wall_seconds=run["seconds"], wheels=wheels, imu=imu,
                all_host_intervals_under_250_ms=max(wheels["max_host_gap_ms"],imu["max_host_gap_ms"])<250,
                telemetry_bytes_per_second=bps, telemetry_percent_115200_8n1=100*bps/11520)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    print(json.dumps(audit(args.directory), indent=2, allow_nan=False))
