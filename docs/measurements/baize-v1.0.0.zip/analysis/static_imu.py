"""Summarize stationary SI telemetry from the full real-port capture."""
import csv
import json
import math
from pathlib import Path
import sys

def summarize(path):
    fields=("ax_m_s2","ay_m_s2","az_m_s2","gx_rad_s","gy_rad_s","gz_rad_s")
    groups={}
    with path.open() as f:
        for r in csv.DictReader(f):
            values=[float(r[k]) for k in fields];values.append(math.hypot(*values[:3]))
            block=int(r["host_elapsed_ms"])//300000
            for key in ("overall",f"five_minute_{block:02}"):
                if key not in groups:groups[key]=[0,[0.]*7,[0.]*7]
                g=groups[key];g[0]+=1
                for i,v in enumerate(values):g[1][i]+=v;g[2][i]+=v*v
    result={}
    for k,(n,s,ss) in groups.items():
        av=[v/n for v in s]
        result[k]=dict(frames=n,mean=[round(v,7) for v in av],
                       sd=[round(math.sqrt(max(0,ms/n-m*m)),7) for ms,m in zip(ss,av)])
    return dict(fields=[*fields,"acceleration_norm_m_s2"],windows=result)

if __name__=="__main__":
    print(json.dumps(summarize(Path(sys.argv[1])),indent=2))
