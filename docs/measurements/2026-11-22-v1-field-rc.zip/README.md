# 白泽移动底盘 · 空载现场验收候选

本包使用 STM32F103RCT6 Release，源码提交 `249aeceff3650ec849b999dce8ad56d91b10286e`。四轮顺序是左前、右前、左后、右后。115200 bit/s、8N1。空载地面速度、停车距离、轮位和 IMU 安装变换在现场验证后随正式版发布。[对应源码](https://github.com/1229282331/baize/tree/249aeceff3650ec849b999dce8ad56d91b10286e)

## 从普通应用连接

本机 Windows 实车端口为 COM17。可先用 `bin/windows-x86_64/baize-monitor.exe COM17 100 --imu-csv imu.csv` 保存六轴样本，轮状态写至标准输出。架空时运行同目录下的 `chassis-example.exe COM17`，四轮各 +0.50 rad/s、持续 300 ms，之后停机、关闭串口、再连接并完成停机握手。Linux x86-64 工具在 `bin/linux-x86_64/`，使用实际串口名。

本次静止长测历时 3609.8 s，收到轮状态 180,500 帧、六轴 180,201 帧。板端最大间隔分别为 20 和 21 ms。主机轮反馈达到 250 ms 过期时限共 3 次，最长 765 ms。六轴在主机的最大到达间隔为 781 ms。双路遥测占上行串口容量 41.64%。

在解压目录运行 `cmake -S examples/chassis -B build/example` 和 `cmake --build build/example` 重建示例。也可以复制示例到仓库外，用 `-DBAIZE_SOURCE_DIR=<解压目录>` 配置。CMake 目标 `baize_host` 供 C/C++ 共用；`lib/` 另提供 Windows MinGW-w64 与 Ubuntu 24.04 x86-64 静态库，头文件位于 `host/`、`protocol/`。[接口、会话及 ROS 2 映射](docs/base-interface.md)

## 固件、回退与核验

本包的 `firmware/`、`protocol/` 含完整固件源码和对应版本的 HAL、CMSIS、链接脚本及工具锁。在 `firmware/` 中依次执行 `cube bundle install --project`、`cube cmake --preset Release`、`cube cmake --build --preset Release`。用配套 Arm 工具的 `arm-none-eabi-objcopy -O binary build/Release/baize_base.elf rebuilt.bin` 导出应用，比较 `rebuilt.bin` 和同目录 `chassis.bin` 的 SHA-256。

四轮架空并用底盘原电源供电。写入本车应用及其原页尾，随后独立读回相同的 22528 字节。

```powershell
cube programmer -c port=SWD freq=480 reset=SWrst -d firmware/chassis-pages.bin 0x08000000 -v -rst
cube programmer -c port=SWD freq=480 mode=HOTPLUG -u 0x08000000 22528 readback.bin
Get-FileHash firmware/chassis-pages.bin,readback.bin -Algorithm SHA256
```

回退时用 `firmware/rollback-pages.bin` 替换写入及哈希比对文件。回退镜像是本车上一份带独立看门狗的 5 ms PI 候选。两份镜像的完整实车读回、切换记录和旧工具兼容试验位于 `records/`。

## 标定与原始记录

单趟地面测量使用 `docs/measurements/ground_trial.py`。独立尺量可用 `ground_geometry.py --turn-angle left 20 28.28` 换算转角，几何标定和复核使用不同的行程。六个静止朝向及另一次水平记录交给 `imu_calibration.py`。[现场说明](https://github.com/1229282331/baize/blob/249aeceff3650ec849b999dce8ad56d91b10286e/docs/bringup-and-acceptance.md#现场用尺验收)

`manifest.json` 记录构建版本、轮控参数、实测项目和待现场填写值。`SHA256SUMS` 列出逐文件哈希。运行 `python analysis/audit_usb.py records` 可从双向通信记录和板端事件重算停机、断流及反馈过期结果。运行 `python analysis/continuous_usb.py records/continuous-usb` 从逐帧 CSV 重算一小时的采样频率、最大间隔、电压和串口占用。台架轮控原始记录和复算程序在 `records/wheel-guard-and-feedforward.zip`。
