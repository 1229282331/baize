# 白泽移动底盘 v1 候选包

源码版本为 `b288715`，串口 v1 使用 115200 bit/s、8N1。此包对应装有 MPU6050 的架空空载实车。地面可用速度、停距、轮位、IMU 安装变换、绝对电压和板载 CH340 验收栏仍待填写。[对应源码和验收记录](https://github.com/1229282331/baize/blob/b28871546f32fe5f889b71845df1e3689377e81d/docs/bringup-and-acceptance.md)

## 上位机接入

解压后，Windows 和 Linux x86-64 的工具位于各自的 `bin/` 子目录。监视命令为 `baize-monitor PORT 250 --imu-csv imu.csv`，四轮状态输出到标准输出。将 `PORT` 换为实际端口名。四轮架空后执行 `chassis-example PORT`，四轮各 +0.5 rad/s，持续 300 ms，随后停机、关闭串口、重新连接并完成停机握手。

包内的 `host/`、`protocol/` 和 `examples/chassis/` 来自同一源码版本。从解压目录运行 `cmake -S examples/chassis -B build/example` 和 `cmake --build build/example` 可自行构建。外部工程链接方法以及轮关节和 IMU 的 ROS 2 映射见[接口说明](docs/base-interface.md)。`manifest.json` 记录源版本、参数、实测范围和待验项；`SHA256SUMS` 包含逐文件 SHA-256。

## 本车烧录与回退

四轮架空时，使用已核对的四线 ST-LINK 接线。候选 Release 应用为 `firmware/candidate.bin`。本车台架实测使用 `candidate-pages.bin`，内含应用及经核对的原 Flash 页尾。下面两条命令分别写入候选、独立读回写入的 36,864 字节。

```powershell
cube programmer -c port=SWD freq=480 reset=SWrst -d firmware/candidate-pages.bin 0x08000000 -v -rst
cube programmer -c port=SWD freq=480 mode=HOTPLUG -u 0x08000000 36864 readback.bin
Get-FileHash firmware/candidate-pages.bin,readback.bin -Algorithm SHA256
```

两份哈希应相同。回退时将写入和比对文件均换为 `firmware/rollback-pages.bin`。它恢复本车前一版已验证的 5 ms PI 固件，源码为 `c4f3cca`，构建预设为 Debug。确认上电未使能、轮速为零、采样时间前进。两次切换均有对应的 49,152 字节独立读回存于 `records/`。

## 记录说明

- `range.json` 和各次点动 CSV 给出轮速、四路 CCR、状态和停机时刻。轮速为 mrad/s。CCR 为 2000 表示中性输出，PWM 幅值为 2000 减 CCR，限幅为 700。窗口均值取最后收令前 100 ms。
- `idle.json`、`moving.json` 和 `production-resets.json` 给出静止及运动时的故障注入、复位标志与实测时间。构建诊断镜像时只在对应源码的独立副本应用 `records/diagnostic.patch`，使用相同 Release 预设。
- `candidate-frames.csv` 为候选镜像真实的板端待发送字节，含 CRC 和分隔符，按 SWD 读取时分段标记。同步传感器寄存器、汇总以及由干净构建回放出的两路 CSV 同存于 `records/`。
- 两份 `consumer-wire.csv`（文件名前缀标识操作系统）及相应日志记录了仓库外 C++ 应用经测试通道与台架实车的一次完整往返。Windows 使用命名管道，Linux 使用伪终端。正式 USB 验收需补录板载 CH340 链路。
