import csv
import json
import math
import os
import sys
from pathlib import Path
from statistics import mean, median

out=Path(sys.argv[1]) if len(sys.argv)>1 else Path(os.environ["LOCALAPPDATA"])/"Baize/Validation/20261122-v1-qualification"
trials=json.loads((out/"ab-trials.json").read_text())
assert len(trials)==60
scores=[]
for trial in trials:
    records=list(csv.DictReader((out/(trial["name"]+".csv")).open()))
    for wheel in ("fl","fr","rl","rr"):
        samples=[(int(r["tick"])-trial["onset"],int(r["speed_"+wheel]),int(r["pwm_"+wheel])) for r in records]
        target=trial["target"]; direction=1 if target>0 else -1
        samples=[(t,v*direction,p) for t,v,p in samples if t>=0]
        diffs=[b[0]-a[0] for a,b in zip(samples,samples[1:])]
        tail=[(t,v,p) for t,v,p in samples if 400<=t<=620]
        assert len(tail)>=30 and len(samples)>=80
        rise=next(t for t,v,p in samples if v>=.9*abs(target))
        overshoot=(max(v for t,v,p in samples)/abs(target)-1)*100
        jumps=[abs(b[2]-a[2]) for a,b in zip(tail,tail[1:]) if b[0]-a[0]==5]
        scores.append(dict(**trial,wheel=wheel,t90_ms=rise,overshoot_pct=max(0,overshoot),
                           mae_mrad_s=mean(abs(v-abs(target)) for t,v,p in tail),
                           mean_pwm_step=mean(jumps),highest_pwm=max(abs(p) for t,v,p in tail),
                           saturated_tail=sum(abs(p)==700 for t,v,p in tail),max_sample_gap_ms=max(diffs)))
def summary(rows):
    p=sorted(r["overshoot_pct"] for r in rows)
    return dict(wheel_trials=len(rows),t90_median_ms=median(r["t90_ms"] for r in rows),
                overshoot_p95_pct=p[math.ceil(.95*len(p))-1],median_tail_mae_mrad_s=median(r["mae_mrad_s"] for r in rows),
                median_pwm_step=median(r["mean_pwm_step"] for r in rows),
                tail_peak_pwm=max(r["highest_pwm"] for r in rows),saturated_tail=sum(r["saturated_tail"] for r in rows),
                observed_max_gap_ms=max(r["max_sample_gap_ms"] for r in rows))
result={}
for phase in ("all","step","reverse"):
    result[phase]={}
    for kv in (.18,.269):
        result[phase][str(kv)]=summary([r for r in scores if r["kv"]==kv and
                                     (phase=="all" or (phase=="step")== (r["previous"]==0))])
with (out/"ab-wheel-results.csv").open("w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=scores[0]);w.writeheader();w.writerows(scores)
(out/"ab-report.json").write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
