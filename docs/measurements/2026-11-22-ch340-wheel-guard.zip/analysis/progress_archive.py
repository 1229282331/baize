"""Reconstruct forward-positive mrad, and the longest sustained effort without progress."""
import csv
import io
import json
import os
import sys
from math import pi
from pathlib import Path
from zipfile import ZipFile

out = Path(sys.argv[1]) if len(sys.argv)>1 else Path(os.environ["LOCALAPPDATA"]) / "Baize/Validation/20261122-v1-qualification"
wheels = ("fl", "fr", "rl", "rr")
signs = (-1, -1, -1, 1)
thresholds = (1, 120, 160, 200, 250, 300)
results = []
for file in sorted(Path("docs/measurements").glob("*wheel*.zip")):
    with ZipFile(file) as z:
        for name in (n for n in z.namelist() if n.endswith("samples.csv")):
            latest = None
            worst = dict.fromkeys(thresholds, (0, "", "", 0))
            rows = 0
            with io.TextIOWrapper(z.open(name), encoding="ascii") as stream:
                for row in csv.DictReader(stream):
                    ms = int(row["ms"])
                    trial = row["trial"]
                    if trial != latest:
                        prev = [0] * 4
                        tracking = {h: [(0, 0, 0)] * 4 for h in thresholds}
                        latest = trial
                    for i, w in enumerate(wheels):
                        target = int(row["target_mrad_s_" + w])
                        angle = round(int(row["raw_" + w]) * signs[i] * (2000*pi/144000))
                        for threshold in thresholds:
                            direction = (1 if target > 0 and prev[i] >= threshold else
                                         -1 if target < 0 and prev[i] <= -threshold else 0)
                            old, mark, start = tracking[threshold][i]
                            if direction == 0 or old != direction or direction * (angle - mark) >= 2:
                                tracking[threshold][i] = (direction, angle, ms)
                            elif ms - start > worst[threshold][0]:
                                worst[threshold] = (ms-start, trial, w, target)
                        prev[i] = int(row["pwm_" + w])
                    rows += 1
            results.append(dict(archive=file.name, entry=name, control_samples=rows, max_gap_ms=worst))
            print(file.name, name, rows, worst, flush=True)
(out / "progress-archive.json").write_text(json.dumps(results, indent=2))
