# 白泽 CH340 架空实测

硬件为本车 STM32F103、四轮架空、板载 CH340、Windows COM17，115200 8N1。
新固件源码 13234e0，Release 应用 SHA-256 为 889d81656c03d632dc053daaf22e83a8a89f01965d796fc63ea9f2c95ea67a6e。
first-usb/ 和 baseline-windows-example.txt 使用上一版候选 b288715，分别记录首次静止收发和独立示例实际点动。

records/frozen-*-wire.csv 按主机单调时间记录双向线帧，包括单轮编码器计数器冻结、故障、忽略旧命令、复位及新的停机握手。physical-faults.json 的四路 CCR 来自在 MCU 连续运行时的 SWD 观测。
ab-trials.json 给出各次给定的板端起点、目标和前馈，每个 ab-N-M-K.csv 是该次实际取到的控制周期、四路 mrad/s 和已施加的 PWM。相应的 -wire.csv 为归档的 USB 双向字节。打开端口时的首个输入片段可能处在帧中间。

在解压目录执行 `python analysis/ab_report.py records` 可复算各轮及总体统计。达到目标 90% 和超调取实际观测的样本，稳态区间取收令后 400～620 ms。从工程仓库根目录执行 `python <解压目录>/analysis/progress_archive.py <解压目录>/records` 可由已有的 wheel 数据包复算无进展窗口。SHA256SUMS 用于核对全部数据文件。
