@echo off
setlocal
pushd "%~dp0..\.." || exit /b 1
if exist "%~dp0baize_panel_io.dll" goto launch
if not exist "build\native\CMakeCache.txt" (
    cmake -S . -B build\native -G Ninja -DCMAKE_C_COMPILER=gcc
    if errorlevel 1 goto failed
)
cmake --build build\native --target baize_panel_io --config Release
if errorlevel 1 goto failed
:launch
where pythonw.exe >nul 2>nul
if errorlevel 1 (
    echo Python 3.10+ with Tk and pythonw.exe must be on PATH.
    goto failed
)
start "" pythonw.exe -B "%~dp0baize-panel.pyw" %*
popd
exit /b 0

:failed
popd
pause
exit /b 1
