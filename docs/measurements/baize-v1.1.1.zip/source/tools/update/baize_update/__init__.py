"""Baize chassis firmware maintenance."""
