# 白泽移动底盘 v1.1.1

适用于白泽 STM32F103RC 四轮底盘及板载 CH340。车载上位机为 RDK X5。固件、主机工具和 SDK 已在此车完成升级、回退与运动回归。首先运行 `sha256sum -c SHA256SUMS` 校验解包后的文件。源码提交、硬件型号、构建工具和实测摘要见 [manifest.json](manifest.json)。

## X5 上的日常操作

```sh
baize-update info
baize-monitor /dev/ttyUSB0 100 --imu-csv imu.csv >wheels.csv
```

第二条命令取得串口并请求停机，采集 100 个轮状态及同期六轴。运行控制程序前先退出监视器。同一串口由一个进程占用，关闭后可以重新连接。

升级时退出占用串口的程序，将整包传到 X5，在解包目录执行以下命令。已有本版的车会检查停车并报告已安装。新装 X5 的 Python 环境准备见[固件升级手册](source/docs/firmware-update.md)。

```sh
sudo /opt/baize-update/venv/bin/pip install -c x5-requirements.txt ./baize_update-1.1.1-py3-none-any.whl
sudo baize-update install ./baize-1.1.1.bin
baize-update info
```

`baize-factory.bin` 用于经 ST-LINK 首装到 `0x08000000`。日常 A–A 升级使用 `baize-1.1.1.bin`。回到已验旧版可执行 `sudo baize-update install ./rollback/baize-1.1.0.bin`。维护串口的访问权即本地构建包的安装权限。包的 SHA-256 和板型检查用于校验完整性与型号。[首装与原始备份恢复方法](source/docs/firmware-update.md#st-link-首装与原版恢复)

## C / C++ 接入

C++ 入口为 `baize::Chassis`，C 入口在 `<baize/chassis.h>`。打开后保持未使能，上层显式使能，周期调用 `read`、`write`，最后调用 `disable` 并关闭。四轮顺序为左前、右前、左后、右后，目标单位 rad/s。两路遥测各自有时间戳和有效标志。

- 应用构建时用 `add_subdirectory(<解包目录>/source baize)` 引入 `baize_host`，再将自己的目标链接到该库。[SDK 接口、单位和 ROS 2 映射](source/docs/base-interface.md) · [C 示例](source/examples/c/main.c) · [C++ 示例](source/examples/chassis/main.cpp)
- 本车 X5 的预编译 SDK 位于 `/opt/baize-sdk/1.1.1/`，内有 `include/`、`lib/libbaize_host.a`、两种语言的示例及接口文档。新板也可直接使用包内的 `source/include/` 和 `linux-arm64/libbaize_host.a`。
- 平台目录提供原生监视工具。Windows 的图形控制台在 `windows-x86_64/tools/panel/启动底盘控制台.cmd`，需要含 Tk 的 64 位 Python 3.10 或以上版本。Windows 预编译静态库使用 MinGW-w64。其他 C/C++ 工具链可从源码构建。
- 已验空载平地直行轮速为双向 0.35、0.50、1.00、1.50 rad/s，接口上限为 ±2.00 rad/s。装臂后的规划上限及车身停距按实际载荷和地面复测。[已有标定与适用工况](source/docs/bringup-and-acceptance.md#空载正式版实车验收)

## 本版实车验收

| 项目 | 本车结果 |
| --- | --- |
| 串口升级 | X5 经 A–A 线从 1.1.0 升到 1.1.1，实测装回旧版后再次安装正式包。最终一次 systemd 升级耗时 12.168 s。 |
| 异常恢复 | X5 在试运行验收中分别忽略轮反馈和 IMU，两次均拒绝确认，STM32 自行退回。另测候选复位入口卡死、上传 2,224 / 24,824 字节中断后立即重试，均可恢复。 |
| 运动与停机 | 由独立链接已安装 SDK 的 C 程序直行、C++ 程序转向，均收到两路反馈，主动停机并重连。另一次四轮同时给 +0.50 rad/s，最后五个使能样本的平均轮速依次为 0.520、0.510、0.506、0.503 rad/s。 |
| 停车连续采集 | 179.973 s 内采集 9,000 个轮样本、8,984 个 IMU 样本。板端频率 50.00 和 49.91 Hz，主机相邻样本最大间隔 21 和 27 ms。全程未使能；紧接点动的首帧左后轮为 −0.044 rad/s，从主机第 42 ms 起四轮零速且角度稳定。 |
| 构建与回归 | Windows 9 项、Linux x86-64 与 X5 各 15 项通过。MCUboot 模拟器 25 项通过，覆盖擦写操作中断。HAL 应用和引导程序与 v1.1.0 的已验二进制逐字节一致。 |

用 `python source/scripts/check_chassis_samples.py records` 可从两路 CSV 和点动记录重算时序、轮速与停稳数据。[同型号单台出厂检查](source/docs/firmware-update.md#同型号单台出厂检查) · [原始记录](records/) · [第三方许可和署名](licenses/) · [软件源码版本](https://github.com/1229282331/baize/tree/v1.1.1)

本次实车验收条件为单台底盘、四轮架空；沿用之前的空载平地数据。真实整车断电、装臂带载以及批量硬件的一致性未在本次试验中测量。
